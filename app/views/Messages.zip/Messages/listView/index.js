import React, { Component } from 'react'
import { FlatList, SafeAreaView, Text, View, Alert, KeyboardAvoidingView, Platform, TouchableOpacity } from 'react-native'
import MessgeData, { userId } from '../data'
import Input from '../inputView'
import MessageItem from '../messageItem'
import ImagePicker from 'react-native-image-crop-picker';

const renderMessages = ({ item, index }) => <MessageItem
    data={item}
    userId={userId}
    onPrimaryAction={() => alert("primary")}
    onSecondaryAction={() => alert("secondary")}
/>

export default class MessageLists extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            dataSet: MessgeData,
            txtMsg: ''
        };
    }

    render() {

        return (<SafeAreaView style={{ flex: 1, backgroundColor: "rgb(24,26,35)" }}>

            <KeyboardAvoidingView keyboardVerticalOffset={100} style={{ flex: 1 }}
                behavior={Platform.OS === 'ios' ? "padding" : null}>
                <FlatList
                    //key={this.state.dataSet.length}
                    data={this.state.dataSet}
                    renderItem={renderMessages}
                    keyboardShouldPersistTaps={'always'}
                    showsVerticalScrollIndicator={false}
                    inverted
                    contentContainerStyle={{ paddingHorizontal: 15 }}
                />
                <Input

                    valForInput={this.state.txtMsg}
                    pickImageVideo={() => {
                        Alert.alert(
                            'Select Media',
                            'Pick from',
                            [
                                {
                                    text: 'Gallery',
                                    onPress: () => {
                                        ImagePicker.openPicker({
                                            width: 500,
                                            height: 500,
                                            cropping: true,
                                            //cropperCircleOverlay: circular,
                                            sortOrder: 'none',
                                            compressImageMaxWidth: 1000,
                                            compressImageMaxHeight: 1000,
                                            compressImageQuality: 0.8,
                                            compressVideoPreset: 'MediumQuality',
                                            includeExif: true,
                                            cropperStatusBarColor: 'white',
                                            cropperToolbarColor: 'white',
                                            cropperActiveWidgetColor: 'white',
                                            cropperToolbarWidgetColor: '#3498DB',
                                            multiple: false
                                            // mediaType: 'photo'
                                        })
                                            .then((image) => {
                                                console.log('received image', image.path);
                                                //this.setState({ avatar: image.path })
                                                this.state.dataSet.push(
                                                    {
                                                        _id: 3,
                                                        _user: {
                                                            _id: 12,
                                                            _avatar: require("../user1.jpeg"),
                                                            _name: "Jason Mamoa"
                                                        },
                                                        _type: "IMAGE_TYPE",
                                                        src: image.path,
                                                        _time: "12.30 AM"
                                                    }
                                                )

                                            })
                                            .catch((e) => {
                                                console.log(e);
                                                // Alert.alert(e.message ? e.message : e);
                                            });
                                    }
                                },
                                {
                                    text: 'Camera', onPress: () => {
                                        ImagePicker.openCamera({
                                            width: 300,
                                            height: 400,
                                            cropping: true,
                                            //mediaType: 'photo'
                                        }).then(image => {
                                            console.log('received image', image.path);
                                            //this.setState({ avatar: image.path })
                                        });
                                    }
                                },
                                {
                                    text: 'Cancel',
                                    onPress: () => console.log('Cancel Pressed'),
                                    style: 'cancel'
                                }
                            ],
                            { cancelable: false }
                        );
                    }}
                    onChange={(msg) => {
                        // alert(msg)
                        this.setState({ txtMsg: msg })
                    }}
                    sendMsg={() => {
                        this.state.dataSet.push(
                            {
                                _id: 3,
                                _user: {
                                    _id: 12,
                                    _avatar: require("../user1.jpeg"),
                                    _name: "Jason Mamoa"
                                },
                                _type: "TEXT_TYPE",
                                _msg: this.state.txtMsg,
                                _time: "12.30 AM"
                            }
                        )
                        this.setState({ txtMsg: '' })

                    }}
                />
            </KeyboardAvoidingView>
        </SafeAreaView>

        )
    }
}


//export default MessageLists