import React from 'react'
import { View, Text, TextInput, Image, TouchableOpacity, Dimensions, Keyboard } from 'react-native'

let wide = Dimensions.get('window').width
const Input = ({ pickImageVideo,
    sendMsg, onChange, valForInput }) => <View style={{ marginVertical: 20, alignItems: 'center', justifyContent: 'center', flexDirection: 'row' }}>
        <TextInput
            style={{
                height: 46, borderRadius: 23, backgroundColor: "rgb(39,42,49)",
                width: "90%", color: '#fff', paddingTop: 15, paddingLeft: 20, paddingRight: wide * 0.28
            }}
            multiline
            placeholder={"Type a message"}
            placeholderTextColor={"rgb(117,118,124)"}
            onChangeText={(e) => onChange(e)}
            value={valForInput}
            autoCorrect={false}
            onSubmit={Keyboard.dismiss(0)}
            blurOnSubmit={true}
        />
        <TouchableOpacity onPress={pickImageVideo}>
            <Image style={{
                position: 'absolute',
                width: 30, height: 30, right: wide * 0.14, bottom: -wide * 0.04
            }} source={require('../Assets/CameraIcon.png')} resizeMode={'contain'} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => sendMsg()}>
            <Image style={{
                position: 'absolute',
                width: 30, height: 30, right: wide * 0.03, bottom: -wide * 0.04, tintColor: '#979797'
            }} source={require('../Assets/sent.png')} resizeMode={'contain'} />
        </TouchableOpacity>
    </View>

export default Input