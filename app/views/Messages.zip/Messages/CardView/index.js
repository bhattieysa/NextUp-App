import React from 'react'
import { View, ImageBackground, Dimensions, Image, TouchableOpacity } from 'react-native'
import Avatar from '../avatar'
import Label from '../label'

let width = Dimensions.get('window').width


const ButtonView = ({ ...props }) => {
    const { _banner, } = props.data;
    const { onPrimaryAction, onSecondaryAction } = props;
    return <View style={{ height: 45, flexDirection: 'row' }}>
        {_banner.primaryBtn && <TouchableOpacity
            style={{ flex: 1, borderTopWidth: 2, borderColor: "#fff", alignItems: 'center', justifyContent: 'center', borderRightWidth: 1 }}
            onPress={onPrimaryAction}
            activeOpacity={0.5}
        >
            <Label
                data={_banner.primaryBtn}
                size={16}
                color={"#fff"}
                bold
            />
        </TouchableOpacity>}
        {_banner.SecondaruBtn && <TouchableOpacity
            style={{ flex: 1, borderTopWidth: 2, borderColor: "#fff", alignItems: 'center', justifyContent: 'center' }}
            onPress={onSecondaryAction}
            activeOpacity={0.5}
        >
            <Label
                data={_banner.SecondaruBtn}
                size={16}
                color={"#fff"}
                bold
            />
        </TouchableOpacity>}
    </View>

}
const BannerView = ({ ...props }) => {
    const { data } = props;
    const { _banner, _time } = data;
    return (
        <ImageBackground
            source={require("../Assets/dummyImage.png")}
            style={{ height: width * 0.45, marginTop: 15 }}
            resizeMode={'cover'}
            imageStyle={{ borderRadius: 20, }}
        >
            <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.2)", borderRadius: 20, }}>
                <View style={{ flex: 1, padding: 15 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Label
                            color={"#fff"}
                            data={_banner.title}
                            bold
                        />
                        <Label
                            color={"#fff"}
                            data={_time}
                            size={12}
                        />
                    </View>
                    <View style={{ flex: 1, flexDirection: 'row', }}>
                        <View style={{ flex: 4, justifyContent: 'center' }}>
                            <Label
                                data={_banner.desc}
                                color={"#fff"}
                            />
                        </View>
                        <View style={{ flex: 1, alignItems: 'flex-end', justifyContent: 'center' }}>
                            <Avatar
                                source={require("../user1.jpeg")}
                                size={60}
                            />
                        </View>
                    </View>
                    <Label
                        data={"Improve!"}
                        color={"#fff"}
                        size={22}
                        italic
                    />
                </View>
                <ButtonView {...props} />
            </View>
        </ImageBackground>
    )
}


export {
    BannerView
}

