import React from 'react'
import { View, Text } from 'react-native'
import Avatar from '../avatar';
import { IMAGE_TYPE, TEXT_TYPE, VIDEO_TYPE } from '../data';
import ImageView from '../imageView';
import Label from '../label';
import VideoView from '../videoView';

const ChatBubble = ({ ...props }) => {
    let user = props.data._user
    let current = user._id == props.userId

    return (
        <View style={{ alignItems: current ? "flex-end" : "flex-start", marginTop: 15 }}>
            <View style={{ width: "70%", flexDirection: 'row', justifyContent: current ? 'flex-end' : 'flex-start', }}>
                {!current && <Avatar
                    size={50}
                    source={user._avatar}
                    bordered
                />}
                <View>
                    {props.data._type == TEXT_TYPE ?
                        <View style={[
                            {
                                marginLeft: current ? 0 : 10,
                                marginRight: current ? 10 : 0,
                                padding: 10,
                                backgroundColor: "rgb(39,42,49)",
                                borderRadius: 20,
                            },
                            current ? { borderTopRightRadius: 5 } : { borderBottomLeftRadius: 5 }
                        ]}>
                            <Label
                                data={props.data._msg}
                                size={12}
                                bold
                                color={"#fff"}
                            />
                        </View>
                        :
                        props.data._type == IMAGE_TYPE ? <ImageView
                            {...props}
                        />
                            :
                            <VideoView
                                {...props}
                            />}
                    <Label
                        data={props.data._time}
                        size={11}
                        color={"grey"}
                        style={{
                            marginLeft: current ? 0 : 15,
                            marginRight: current ? 15 : 0,
                            alignSelf: current ? "flex-start" : "flex-end",
                            marginTop: 5
                        }}
                    />
                </View>

                {current && <Avatar
                    size={50}
                    bordered
                    source={user._avatar}
                />}
            </View>
        </View>
    )
}

export default ChatBubble
