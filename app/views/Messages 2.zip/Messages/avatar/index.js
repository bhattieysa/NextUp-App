import React from 'react'
import { Image } from 'react-native'
const Avatar = ({ source, size, bordered }) => <Image
    style={[{ height: size, width: size, borderRadius: size / 2 }, bordered && { borderWidth: 2, borderColor: "rgb(39,42,49)" }]}
    source={source}
    resizeMode={'cover'}
/>

export default Avatar
