import React, { useState } from 'react'
import { View, Image, TouchableOpacity, Animated, Dimensions, Modal, SafeAreaView, Text } from 'react-native'

const { height, width } = Dimensions.get('window')

const ImageView = ({ ...props }) => {
    let user = props.data._user
    let current = user._id == props.userId
    const value = useState(new Animated.ValueXY({ x: 0, y: 0 }))[0];
    const [show, onShow] = useState(false)
    const handleZoom = () => {
        Animated.spring(value, {
            toValue: { x: width, y: height },
            speed: 1,
            useNativeDriver: false
        }).start()
        setTimeout(() => {
            onShow(true)
        }, 100);
    }

    const dismissImage = () => {
        Animated.spring(value, {
            toValue: { x: 0, y: 0 },
            speed: 1,
            useNativeDriver: false
        }).start()
        setTimeout(() => {
            onShow(false)
        }, 100);
    }

    return (

        <TouchableOpacity onPress={handleZoom}>
            <Image
                source={{ uri: props.data.src }}
                style={[
                    {
                        marginLeft: current ? 0 : 10,
                        marginRight: current ? 10 : 0,
                        borderRadius: 20, width: 200, height: 200
                    },
                    current ? { borderTopRightRadius: 5 } : { borderBottomLeftRadius: 5 }
                ]}
                resizeMode={'cover'}
            />
            <Modal visible={show}>
                <SafeAreaView style={{ flex: 1, backgroundColor: "rgb(39,42,49)" }}>
                    <TouchableOpacity onPress={dismissImage} style={{
                        height: 40, width: 40, borderWidth: 2, borderColor: '#fff', borderRadius: 20, justifyContent: 'center', alignItems: 'center',
                        zIndex: 99, marginLeft: 20, marginTop: width * 0.05
                    }}>
                        <Text style={{ fontSize: 22, color: '#fff', }}>X</Text>
                    </TouchableOpacity>
                    <Animated.Image
                        resizeMode={'contain'}
                        source={{ uri: props.data.src }} style={[{
                            position: 'absolute',
                            top: 0,
                            right: 0,
                            bottom: 0,
                            left: 0,
                            height: value.y,
                            width: value.x,
                        }]}>

                    </Animated.Image>
                </SafeAreaView>
            </Modal>
        </TouchableOpacity>
    )
}

export default ImageView
