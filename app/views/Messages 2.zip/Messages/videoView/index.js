import React, { useState } from 'react'
import { View, Text, Image, ImageBackground, Dimensions, TouchableOpacity, Modal } from 'react-native'
//import Icon from 'react-native-vector-icons/FontAwesome'
import VideoPlayer from './player'

let wide = Dimensions.get('window').width

const VideoView = ({ ...props }) => {
    let user = props.data._user
    let current = user._id == props.userId
    const [isplay, onChange] = useState(false)
    return (
        <>
            <TouchableOpacity onPress={() => onChange(true)}>
                <ImageBackground
                    source={props.data.src}
                    imageStyle={[
                        {
                            borderRadius: 20,
                        },
                        current ? { borderTopRightRadius: 5 } : { borderBottomLeftRadius: 5 }
                    ]}
                    style={[
                        {
                            marginLeft: current ? 0 : 10,
                            marginRight: current ? 10 : 0,
                            height: 180,
                            width: wide * .6,
                            borderRadius: 20,
                            justifyContent: 'center',
                            alignItems: 'center'
                        },
                    ]}
                >
                    <Image
                        style={{ width: 30, height: 30 }}
                        source={require('../Assets/play_ico_tint.png')}
                    />
                    {/* <Icon
                        name={"play-circle-o"}
                        size={40}
                        color={"#fff"}
                    /> */}
                </ImageBackground>
            </TouchableOpacity>
            <Modal visible={isplay}>
                <VideoPlayer
                    source={{ uri: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" }}
                    close={() => onChange(false)}
                />
            </Modal>
        </>
    )
}

export default VideoView
